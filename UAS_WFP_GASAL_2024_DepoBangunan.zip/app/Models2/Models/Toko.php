<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Toko extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama',
        'no_hp',
        'email',
        'alamat',
        'kota',
        'provinsi',
        'negara',
        'kode_pos',
        'kecamatan',
        'keterangan',
    ];

    public function produks()
    {
        return $this->belongsToMany(Produk::class, 'produk_tokos');
    }
}
