<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProdukToko extends Model
{
    use HasFactory;

    public $timestamps = false;

    public function pembelians()
    {
        return $this->belongsToMany(Pembelian::class, 'nota_beli_details', 'id', 'id');
    }

    public function pelanggans()
    {
        return $this->belongsToMany(Pelanggan::class, 'keranjangs');
    }

    public function keranjangs()
    {
        return $this->hasMany(Keranjang::class);
    }
}
