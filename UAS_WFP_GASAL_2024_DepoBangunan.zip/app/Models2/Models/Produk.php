<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Produk extends Model
{
    use HasFactory;

    protected $fillable = [
        'merk_id',
        'subkategori_id',
        'sku',
        'nama',
        'tipe',
        'foto_produk',
        'harga',
        'total_stok',
        'publikasi',
        'warna',
        'permukaan',
        'bentuk',
        'material',
        'finishing',
        'penggunaan',
        'ukuran',
        'volume',
        'harga_spesial',
        'tgl_mulai_harga_spesial',
        'tgl_selesai_harga_spesial',
        'deskripsi',
    ];

    
    public function transaksis()
    {
        return $this->belongsToMany(Transaksi::class, 'detail_transaksis');
    }

    public function wishlists()
    {
        return $this->belongsToMany(Pelanggan::class, 'wishlists');
    }

    public function ruangans()
    {
        return $this->belongsToMany(Ruangan::class, 'produk_ruangans');
    }

    public function tokos()
    {
        return $this->belongsToMany(Toko::class, 'produk_tokos');
    }

    public function merks()
    {
        return $this->belongsTo(Merk::class);
    }

    public function subkategoris()
    {
        return $this->belongsTo(SubKategori::class);
    }
}
