<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detail_transaksis', function (Blueprint $table) {
            $table->unsignedBigInteger('transaksi_id');
            $table->foreign('transaksi_id')->references('id')->on('transaksis');
            $table->unsignedBigInteger('pt_produk_id');
            $table->foreign('pt_produk_id')->references('produk_id')->on('produk_tokos');
            $table->double('diskon');
            $table->integer('kuantitas');
            $table->double('total');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        
        Schema::table('detail_transaksis', function (Blueprint $table) {
            $table->dropForeign(['transaksi_id']);
            $table->dropColumn('transaksi_id');
            $table->dropForeign(['pt_produk_id']);
            $table->dropColumn('pt_produk_id');
        });
        Schema::dropIfExists('detail_transaksis');
       
    }
};
