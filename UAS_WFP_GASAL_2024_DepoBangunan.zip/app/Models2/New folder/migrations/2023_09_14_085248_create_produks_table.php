<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('produks', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('merk_id');
            $table->foreign('merk_id')->references('id')->on('merks');
            $table->unsignedBigInteger('subkategori_id');
            $table->foreign('subkategori_id')->references('id')->on('subkategoris');
            $table->string('sku')->unique();
            $table->string('nama');
            $table->string('tipe');
            $table->string('foto_produk')->nullable();
            $table->double('harga');
            $table->integer('total_stok')->nullable();
            $table->string('publikasi')->nullable();
            $table->string('warna')->nullable();
            $table->string('permukaan')->nullable();
            $table->string('bentuk')->nullable();
            $table->string('material')->nullable();
            $table->string('finishing')->nullable();
            $table->string('penggunaan')->nullable();
            $table->string('ukuran')->nullable();
            $table->string('volume')->nullable();
            $table->double('harga_spesial')->nullable();
            $table->timestamp('tgl_mulai_harga_spesial')->nullable();
            $table->timestamp('tgl_selesai_harga_spesial')->nullable();
            $table->text('deskripsi')->nullable();
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('produks', function (Blueprint $table) {
            $table->dropForeign(['merk_id']);
            $table->dropColumn('merk_id');
            $table->dropForeign(['tipe_id']);
            $table->dropColumn('tipe_id');
        });
        Schema::dropIfExists('produks');
    }
};
