<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class ProdukRuanganSeeder extends Seeder
{

    public function run()
    {
        DB::statement('SET foreign_key_checks=0;');

        DB::table('produk_ruangans')->insert([
            ['produk_id' => 1,
                'ruangan_id' => 1,],
            ['produk_id' => 1,
                'ruangan_id' => 2,],
            ['produk_id' => 2,
                'ruangan_id' => 1,],
        ]);

        DB::statement('SET foreign_key_checks=1;');
    }
}
