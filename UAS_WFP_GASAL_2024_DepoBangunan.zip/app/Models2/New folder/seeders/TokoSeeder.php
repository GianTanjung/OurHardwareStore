<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TokoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tokos')->insert([
            'nama' => 'Depo Sidoarjo',
            'no_hp' => '081133308281',
            'email' => 'deposidoarjo@info.com',
            'alamat' => 'Jl Ahmad Yani 41',
            'kode_pos' => '61254',
            'kecamatan' => 'Gedangan',
            'kota' => 'Kabupaten Sidoarjo',
            'provinsi' => 'Jawa Timur',
            'negara' => 'Indonesia',
        ]);
        DB::table('tokos')->insert([
            'nama' => 'Depo Malang',
            'no_hp' => '081133308281',
            'email' => 'depomalang@info.com',
            'alamat' => 'Jl Raya Karanglo 69',
            'kode_pos' => '65153',
            'kecamatan' => 'Blimbing',
            'kota' => 'Kota Malang',
            'provinsi' => 'Jawa Timur',
            'negara' => 'Indonesia',
        ]);
        DB::table('tokos')->insert([
            'nama' => 'Depo Surabaya',
            'no_hp' => '089683213464',
            'email' => 'deposurabaya@info.com',
            'alamat' => 'Jl Rajawali 55',
            'kode_pos' => '60175',
            'kecamatan' => 'Krembangan',
            'kota' => 'Kota Surabaya',
            'provinsi' => 'Jawa Timur',
            'negara' => 'Indonesia',
        ]);
    }
}
