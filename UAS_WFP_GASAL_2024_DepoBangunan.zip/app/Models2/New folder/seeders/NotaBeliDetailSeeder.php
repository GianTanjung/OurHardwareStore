<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class NotaBeliDetailSeeder extends Seeder
{
    public function run()
    {
        // DB::statement('SET foreign_key_checks=0;');

        DB::table('nota_beli_details')->insert([
            ['nota_beli_id' => 1,
                'produk_id' => 1,
                'harga' => 60000,
                'qty' => 500,
                'subtotal' => 30000000],           
        ]);

        // DB::statement('SET foreign_key_checks=1;');
    }
}
