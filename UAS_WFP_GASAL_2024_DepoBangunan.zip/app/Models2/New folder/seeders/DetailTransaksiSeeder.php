<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetailTransaksiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::statement('SET foreign_key_checks=0;');
        DB::table('detail_transaksis')->insert([
            ['transaksi_id' => 1,
                'produk_id' => 1,
                'kuantitas' => 3,
                'total' => 800000,
                'diskon' => 0],
            ['transaksi_id' => 1,
                'produk_id' => 2,
                'kuantitas' => 4,
                'total' => 800000,
                'diskon' => 0],
        ]);
        DB::table('detail_transaksis')->insert([
            ['transaksi_id' => 2,
                'produk_id' => 1,
                'kuantitas' => 2,
                'total' => 800000,
                'diskon' => 0],
            ['transaksi_id' => 2,
                'produk_id' => 1,
                'kuantitas' => 2,
                'total' => 800000,
                'diskon' => 0],
        ]);
        DB::table('detail_transaksis')->insert([
            ['transaksi_id' => 3,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
            ['transaksi_id' => 3,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
        ]);
        DB::table('detail_transaksis')->insert([
            ['transaksi_id' => 4,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
            ['transaksi_id' => 4,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
        ]);
        DB::table('detail_transaksis')->insert([
            ['transaksi_id' => 5,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
            ['transaksi_id' => 5,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
        ]);
        DB::table('detail_transaksis')->insert([
            ['transaksi_id' => 6,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
            ['transaksi_id' => 6,
                'produk_id' => 1,
                'kuantitas' => 6,
                'total' => 800000,
                'diskon' => 0],
        ]);

    }
}
