<?php

namespace Database\Seeders;

use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class NotaBeliSeeder extends Seeder
{
    public function run()
    {
        DB::table('nota_belis')->insert([
            ['tgl_pesan' => Carbon::now(),
                'tgl_terima' => Carbon::now()->addDays(7),
                'kode_nota' => 'INV16720974',
                'supplier_id' => 1,
                'toko_id' => 1,
                'grand_total' => 30000000,]
        ]);
    }
}
