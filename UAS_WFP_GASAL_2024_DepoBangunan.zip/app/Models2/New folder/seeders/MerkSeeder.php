<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class MerkSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('merks')->insert([
            'nama' => 'American Standard',
            'foto_merk' => 'merks/american_standard.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Asian Paints',
            'foto_merk' => 'merks/asianpaints.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Avian',
            'foto_merk' => 'merks/avian.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Dekson',
            'foto_merk' => 'merks/dekson.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Dulux',
            'foto_merk' => 'merks/dulux.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Meridian',
            'foto_merk' => 'merks/meridian.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Modena',
            'foto_merk' => 'merks/modena.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Mowilex',
            'foto_merk' => 'merks/mowilex.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Nippon Paint',
            'foto_merk' => 'merks/nippon_paint.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Panasonic',
            'foto_merk' => 'merks/panasonic.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Philips',
            'foto_merk' => 'merks/philips.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Roman',
            'foto_merk' => 'merks/roman.jpg'
        ]);
        DB::table('merks')->insert([
            'nama' => 'Sandimas',
            'foto_merk' => 'merks/sandimas.jpg'
        ]);
        // DB::table('merks')->insert([
        //     'nama' => 'Sanlex',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
        // DB::table('merks')->insert([
        //     'nama' => 'Flexy Coat',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
        // DB::table('merks')->insert([
        //     'nama' => 'Arca',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
        // DB::table('merks')->insert([
        //     'nama' => 'Brillo',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
        // DB::table('merks')->insert([
        //     'nama' => 'Magix',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
        // DB::table('merks')->insert([
        //     'nama' => 'Aquaproof',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
        // DB::table('merks')->insert([
        //     'nama' => 'SCG',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
        // DB::table('merks')->insert([
        //     'nama' => 'Milan',
        //     'foto_merk' => 'https://picsum.photos/200/300'
        // ]);
    }
}
