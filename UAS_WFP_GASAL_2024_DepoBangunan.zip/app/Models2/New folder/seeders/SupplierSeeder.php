<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class SupplierSeeder extends Seeder
{
    public function run()
    {
        DB::table('suppliers')->insert([
            ['nama' => 'PT Kharisma Sejahtera',
                'no_hp' => '0812345678',
                'email' => 'kharismasejahtera@gmail.com',
                'alamat' => 'Jl Letjen Suprapto Pert Cempaka Putih 3',
                'kota' => 'Kota Jakarta Pusat',
                'provinsi' => 'DKI Jakarta',
                'negara' => 'Indonesia',
                'kode_pos' => '10510',
                'kecamatan' => 'Sukolilo'
            ],

            ['nama' => 'PT Alam Makmur',
                'no_hp' => '0812345678',
                'email' => 'alammakmur@gmail.com',
                'alamat' => 'Jl Raya Batu Indah 39',
                'kota' => 'Kota Bandung',
                'provinsi' => 'Jawa Barat',
                'negara' => 'Indonesia',
                'kode_pos' => '40266',
                'kecamatan' => 'Sukolilo'
            ],

            ['nama' => 'PT Lancar Rejeki',
                'no_hp' => '0812345678',
                'email' => 'lancarrejeki@gmail.com',
                'alamat' => 'Jl Puspowarno Tgh IX 2',
                'kota' => 'Kota Semarang',
                'provinsi' => 'Jawa Tengah',
                'negara' => 'Indonesia',
                'kode_pos' => '50149',
                'kecamatan' => 'Sukolilo'
            ],
        ]);
    }
}
