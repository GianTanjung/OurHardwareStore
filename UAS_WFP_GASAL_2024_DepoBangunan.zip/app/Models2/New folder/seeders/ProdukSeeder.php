<?php

namespace Database\Seeders;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class ProdukSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //AVIAN
        DB::table('produks')->insert([
            'subkategori_id' => 14,
            'merk_id' => 1,
            'nama' => 'AVIAN GLOSS SUPER WHITE',
            'sku' => 'AVIAN0300060023',
            'tipe' => 'Cat Kayu dan Besi',
            'foto_produk' => 'produks/avian0300060023_pa.jpg',
            'harga' => 73100,
            'total_stok' => 460,
            'publikasi' => 'Ya',
            'warna' => 'Putih Super',
            'penggunaan' => 'Exterior',
            'finishing' => 'Gloss',
            'volume' => '0.9L',
            'deskripsi' => 'cat Avian Gloss Super White. Cat ini memiliki beberapa keunggulan, termasuk kecerahan dan kehalusannya. Dengan formula khususnya, cat ini memberikan hasil akhir yang tahan lama, mengkilap, dan melindungi dari cuaca dan sinar UV.

            Cat Avian Gloss Super White dapat digunakan pada berbagai permukaan, seperti kayu, logam, beton, dan material lainnya. Keunggulannya adalah mudah diaplikasikan dan menghasilkan lapisan yang halus dan merata.
            
            Tingkatkan keindahan dan perlindungan permukaan Anda dengan menggunakan cat Avian Gloss Super White. Dapatkan hasil yang memukau dan tahan lama dengan cat berkualitas tinggi dari Avian. Beritahu saya jika Anda memiliki pertanyaan lebih lanjut atau jika ada hal lain yang dapat saya bantu.
            
            Spesifikasi Produk :
            - Merk : Avian
            - Kode Warna : SW Super White
            - Berat Nett : 0,9 Liter
            - Cat Kayu dan Besi
            
            Keunggulan Produk :
            - Mengkilap sempurna
            - Anti karat
            - Cepat kering
            - Tahan cuaca
            - Daya tutup terbaik
            - Fleksibel, tak mudah retak
            - Tahan air laut
            - Anti jamur dan rayap',
        ]);
        DB::table('produks')->insert([
            'subkategori_id' => 14,
            'merk_id' => 6,
            'nama' => 'HABITAT KERAMIK FLOOR TILE CARRARA SLVR 1.08M2 KW1 60X60CM SILVER',
            'sku' => 'MILAN0205850001',
            'tipe' => 'Keramik Lantai',
            'foto_produk' => 'produks/milan0205850001_fl.jpg',
            'harga' => 118368,
            'total_stok' => 460,
            'publikasi' => 'Ya',
            'warna' => 'Abu-Abu',
            'material' => 'Keramik',
            'permukaan' => 'Kilap',
            'bentuk' => 'Solid and Firm',
            'ukuran' => '60X60CM',
            'harga_spesial' => 92327,
            'tgl_mulai_harga_spesial' => '2023-12-13 00:00:00',
            'tgl_selesai_harga_spesial' => '2023-12-31 00:00:00',
            'deskripsi' => 'Ubin Keramik Lantai Carrara Silver 60x60 adalah pilihan tepat untuk Anda yang mencari ubin keramik lantai berkualitas tinggi dengan desain yang elegan dan tahan lama. Ubin ini terbuat dari bahan keramik berkualitas tinggi yang tahan terhadap chipping, goresan, dan noda. Desain marmer klasik dengan warna silver memberikan tampilan yang elegan dan mewah, cocok untuk berbagai ruangan di rumah Anda.

                Keunggulan Ubin Keramik Lantai Carrara Silver 60x60:

                Kualitas bahan yang tinggi
                Desain yang elegan
                Tahan lama
                Mudah dirawat

                Aplikasi Ubin Keramik Lantai Carrara Silver 60x60:

                Lantai
                Dinding
                Meja dapur
                Backsplash

                Cara Perawatan Ubin Keramik Lantai Carrara Silver 60x60:

                Bersihkan noda ringan dengan air sabun
                Gunakan pembersih khusus untuk keramik untuk noda yang lebih membandel',
        ]);
    }
}
