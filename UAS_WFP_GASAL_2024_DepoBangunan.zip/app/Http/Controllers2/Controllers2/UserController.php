<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Province;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function logout()
    {
        Auth::logout();

        return redirect('/'); // You can customize the redirection URL after logout
    }
    
    public function index()
    {
        $queryBuilder = DB::table('users')->get();

        return view('user.index',compact('queryBuilder'));
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(User $user)
    {
        //
    }

    public function edit(User $user)
    {
        //
    }

    public function update(Request $request, User $user)
    {
        // 
    }

    public function destroy(User $user)
    {
        //
    }
}
