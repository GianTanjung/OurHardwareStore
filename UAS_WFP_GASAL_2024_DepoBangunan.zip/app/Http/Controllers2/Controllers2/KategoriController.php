<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use App\Models\Kategori;
use App\Models\SubKategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KategoriController extends Controller
{
    public function index()
    {
        $title = 'Delete Data!';
        $text = "Are you sure you want to delete?";
        confirmDelete($title, $text);

        $kategoris = Kategori::all();
        return view('master.kategori.daftarkategori', compact('kategoris'));
    }

    public function create()
    {
        return view('master.kategori.insertkategori');
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        $validatedData = $request->validate([
            'nama' => 'required',
        ], [
            'nama.required' => 'Wajib diisi!',
        ]);

        try {

            Kategori::create($validatedData);

            DB::commit();

            toast('Penambahan data berhasil!', 'success');
            return redirect()->route('kategori.create');

        } catch (\Exception $e) {
            DB::rollback();

            toast('Penambahan data gagal!', 'warning');
            return redirect()->route('kategori.create');
        }
    }

    public function show(Kategori $kategori)
    {
        //
    }

    public function edit($id)
    {
        $kategoris = Kategori::where('id', $id)
            ->get();

        return view('master.kategori.editkategori', compact('kategoris'));
    }

    public function update(Request $request, $id)
    {
        DB::beginTransaction();

        $kategori = Kategori::find($id);

        $validatedData = $request->validate([
            'nama' => 'required',
        ], [
            'nama.required' => 'Wajib diisi!',
        ]);

        try {

            $kategori->update($validatedData);

            DB::commit();

            toast('Perubahan data berhasil!', 'success');
            return redirect()->route('kategori.edit', $id);

        } catch (\Exception $e) {
            DB::rollback();

            toast('Perubahan data gagal!', 'warning');
            return redirect()->route('kategori.edit', $id);
        }
    }

    public function destroy($id)
    {
        DB::beginTransaction();

        try {

            $cekKategoriOnSubKategori = SubKategori::where('kategori_id', $id)
                ->first();

            if ($cekKategoriOnSubKategori == null) {

                DB::statement('SET foreign_key_checks = 0');
                Kategori::find($id)->delete();
                DB::statement('SET foreign_key_checks = 1');

                DB::commit();

                alert()->success('Berhasil!', 'Penghapusan Data Berhasil!');
                return redirect()->route('kategori.index');
            } else {
                alert()->error('Gagal!', 'Tidak bisa menghapus data, karena ada sub kategori yang menggunakan kategori ini');
                return redirect()->route('kategori.index');
            }

        } catch (\Exception $e) {
            DB::rollback();

            // echo ($e);
            alert()->error('Yahhh..', 'Menghapus data tidak berhasil!');
            return redirect()->route('kategori.index');
        }
    }
}
