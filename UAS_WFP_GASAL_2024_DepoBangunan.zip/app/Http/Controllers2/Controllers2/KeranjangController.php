<?php

namespace App\Http\Controllers;

use App\Models\Keranjang;
use App\Models\Pelanggan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class KeranjangController extends Controller
{
    public function index(Request $request)
    {
        $user = Auth::user();

        $pelanggan = Pelanggan::where('user_id', $user->id)->first();

        $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.pt_produk_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->get();


        $subTotal = Keranjang::join('produk_tokos', 'produk_tokos.produk_id', '=', 'keranjangs.pt_produk_id')
            ->join('produks', 'produks.id', '=', 'produk_tokos.produk_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->sum(DB::raw('produks.harga * keranjangs.kuantitas'));

        $vat = $subTotal * 20 / 100;
        $total = $subTotal + $vat;


        $store = Keranjang::join('produk_tokos', 'produk_tokos.produk_id', '=', 'keranjangs.pt_produk_id')
            ->join('tokos', 'tokos.id', '=', 'produk_tokos.toko_id')
            ->select('tokos.*')
            ->get();

        $sidoarjo = Keranjang::where('keranjangs.pt_toko_id', 1)->count();
        $malang = Keranjang::where('keranjangs.pt_toko_id', 2)->count();
        $surabaya = Keranjang::where('keranjangs.pt_toko_id', 3)->count();

        $choosen = $request->input('produk', []);
        $message = '';
        $count = 0;
        if ($choosen == null) {

            $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.pt_produk_id')
                ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
                ->where('keranjangs.pelanggan_id', $pelanggan->id)
                ->get();

            $subTotal = 0;
            $vat = 0;
            $total = 0;

            $store = Keranjang::join('produk_tokos', 'produk_tokos.produk_id', '=', 'keranjangs.pt_produk_id')
                ->join('tokos', 'tokos.id', '=', 'produk_tokos.toko_id')
                ->select('tokos.*')
                ->get();

            $sidoarjo = Keranjang::where('keranjangs.pt_toko_id', 1)->count();
            $malang = Keranjang::where('keranjangs.pt_toko_id', 2)->count();
            $surabaya = Keranjang::where('keranjangs.pt_toko_id', 3)->count();
        } else {

            $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.pt_produk_id')
                ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
                ->where('keranjangs.pelanggan_id', $pelanggan->id)
                ->get();

            $subTotal = Keranjang::join('produk_tokos', 'produk_tokos.produk_id', '=', 'keranjangs.pt_produk_id')
                ->join('produks', 'produks.id', '=', 'produk_tokos.produk_id')
                ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
                ->where('keranjangs.upelanggan_id', $pelanggan->id)
                ->sum(DB::raw('produks.harga * keranjangs.kuantitas'));

            $vat = $subTotal * 11 / 100;
            $total = $subTotal + $vat;

            $store = Keranjang::join('produk_tokos', 'produk_tokos.produk_id', '=', 'keranjangs.pt_produk_id')
                ->join('tokos', 'tokos.id', '=', 'produk_tokos.toko_id')
                ->select('tokos.*')
                ->get();

            $sidoarjo = Keranjang::where('keranjangs.pt_toko_id', 1)->count();
            $malang = Keranjang::where('keranjangs.pt_toko_id', 2)->count();
            $surabaya = Keranjang::where('keranjangs.pt_toko_id', 3)->count();

            // dd($subTotal);

            $toko = DB::table('keranjangs')->select('toko_id')->whereIn('id', $choosen)->groupBy('toko_id')->get();
            foreach ($toko as $t) {
                $count += 1;
                if ($count > 1) {
                    // return redirect()->back()->with('message', 'Products must be from the same store.');
                    // echo 'works';
                    $message = 'Products must be from the same store.';
                }
            }

        }

        return view('checkout.cart', compact('listCart', 'subTotal', 'vat', 'total', 'store', 'sidoarjo', 'malang', 'surabaya', 'choosen', 'message', 'count'));
    }

    public function create()
    {
        //
    }

    public function store(Request $request, $id)
    {
        $user = Auth::user();

        $selectedstore = $request->input('lokasi');
        // $store = DB::table('tokos')->select('id')->where('id', '=', $selectedstore)->first();

        if ($request->input('kuantitas') > 0) {
            $jumlah = $request->input('kuantitas');
        } else {
            $jumlah = 1;
        }

        $helper = Keranjang::where('user_id', $user->id)
            ->where('pt_produk_id', $id)
            ->first();

        if ($helper != null && $helper->toko_id == $selectedstore) {
            Keranjang::where('id', $helper->id)
                ->update([
                    'kuantitas' => ($helper->kuantitas + 1),
                    // Add more columns as needed
                ]);
        } else {
            $data = array('pt_produk_id' => $id, 'user_id' => $user->id, 'kuantitas' => $jumlah, 'pt_toko_id' => $selectedstore);
            Keranjang::insert($data);
        }


        return redirect()->back();
    }

    public function show(Keranjang $keranjang)
    {
        //
    }

    public function edit(Keranjang $keranjang)
    {
        //
    }

    public function update(Request $request, $id, $value)
    {
        $user = Auth::user();

        $helper = Keranjang::where('user_id', $user->id)->where('produk_id', $id)->first();

        if ($helper->kuantitas != $value) {
            $helper->kuantitas = $value;
        }
        $helper->update();
        return redirect()->route('cart');
    }

    public function destroy(Keranjang $keranjang)
    {
        //
    }

    public function deleteCart($id)
    {
        Keranjang::where('id', $id)->delete();

        return redirect()->back();
    }

    public function deleteOutCart($id)
    {
        Keranjang::where('id', $id)->delete();

        return redirect()->back();
    }

    public function updateQuantity($id)
    {
        $quantity = Keranjang::find($id);
        $quantity->kuantitas += 1;
        $quantity->save();

        return response()->json(['success' => true, 'message' => 'Count increased successfully']);
    }

    public function checkout($products)
    {
        $user = Auth::user();
        // $products = $request->input('produk', []);
        // $listCart = DB::table('keranjangs as k')->select('k.id')->where('k.user_id', '=', $user->id)->whereIn('k.id', $products)->groupBy('k.toko_id')->get();

        $count = Keranjang::select('id')
            ->where('user_id', $user->id)
            ->whereIn('id', $products)
            ->groupBy('toko_id')
            ->count();

        // $count = $listCart->count();

        if ($count > 1) {
            return redirect()->back()->with('message', 'Products must be from the same store.');
            // dd($count);
        } else {
            return redirect()->back();
        }
        // dd($listCart);
    }
}
