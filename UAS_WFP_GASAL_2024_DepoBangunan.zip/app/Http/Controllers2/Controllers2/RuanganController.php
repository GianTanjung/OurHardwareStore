<?php

namespace App\Http\Controllers;

use App\Models\ProdukRuangan;
use Illuminate\Http\Request;
use App\Models\Produk;
use App\Models\Ruangan;
use Illuminate\Support\Facades\DB;

class RuanganController extends Controller
{
    public function index()
    {
        $title = 'Delete Data!';
        $text = "Are you sure you want to delete?";
        confirmDelete($title, $text);
        
        $ruangans = Ruangan::all();
        return view('master.ruangan.daftarruangan', compact('ruangans'));
    }

    public function create()
    {
        return view('master.ruangan.insertruangan');
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        $validatedData = $request->validate([
            'nama' => 'required',
        ], [
            'nama.required' => 'Wajib diisi!',
        ]);

        try {

            Ruangan::create($validatedData);

            DB::commit();

            toast('Penambahan data berhasil!', 'success');
            return redirect()->route('ruangan.create');

        } catch (\Exception $e) {
            DB::rollback();

            toast('Penambahan data gagal!', 'warning');
            return redirect()->route('ruangan.create');
        }
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $detailRuangan = Ruangan::where('id', $id)
            ->get();

        return view('master.ruangan.editruangan', compact('detailRuangan'));
    }

    public function update(Request $request, $id)
    {
        DB::beginTransaction();

        $ruangan = Ruangan::find($id);

        $validatedData = $request->validate([
            'nama' => 'required',
        ], [
            'nama.required' => 'Wajib diisi!',
        ]);

        try {

            $ruangan->update($validatedData);

            DB::commit();

            toast('Perubahan data berhasil!', 'success');
            return redirect()->route('ruangan.edit', $id);

        } catch (\Exception $e) {
            DB::rollback();

            toast('Perubahan data gagal!', 'warning');
            return redirect()->route('ruangan.edit', $id);
        }
    }

    public function destroy($id)
    {
        DB::beginTransaction();

        try {

            $cekRuanganProduk = ProdukRuangan::where('ruangan_id', $id)
                ->first();

            if ($cekRuanganProduk == null) {

                DB::statement('SET foreign_key_checks = 0');
                Ruangan::find($id)->delete();
                DB::statement('SET foreign_key_checks = 1');

                DB::commit();

                alert()->success('Berhasil!', 'Penghapusan Data Berhasil!');
                return redirect()->route('ruangan.index');
            } else {
                alert()->error('Gagal!', 'Tidak bisa menghapus data, karena ada produk yang menggunakan ruangan ini');
                return redirect()->route('ruangan.index');
            }

        } catch (\Exception $e) {
            DB::rollback();

            // echo ($e);
            alert()->error('Yahhh..', 'Menghapus data tidak berhasil!');
            return redirect()->route('ruangan.index');
        }
    }
}
