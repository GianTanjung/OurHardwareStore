<?php

namespace App\Http\Controllers;

use App\Models\Dompet;
use Carbon\Carbon;
use App\Models\City;
use App\Models\Toko;
use App\Models\User;
use App\Models\Produk;
use App\Models\Kategori;
use App\Models\Province;
use App\Models\Keranjang;
use App\Models\Pelanggan;
use App\Models\Transaksi;
use App\Models\ProdukToko;
use Illuminate\Http\Request;
use App\Models\DetailTransaksi;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class PelangganController extends Controller
{
    public function index()
    {
        $title = 'Delete Data!';
        $text = "Are you sure you want to delete?";
        confirmDelete($title, $text);

        $pelanggans = Pelanggan::all();
        return view('pengaturan.pelanggan.daftarpelanggan', compact('pelanggans'));
    }

    public function create()
    {
        $users = User::where('users.role_id', 3)
            ->get();

        $provinsis = Province::all();

        return view('pengaturan.pelanggan.insertpelanggan', compact('users', 'provinsis'));
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        $validatedData = $request->validate([
            'user_id' => 'required',
            'nama' => 'required',
            'no_hp' => 'required',
            'alamat' => 'required',
            'kode_pos' => 'required',
            'kecamatan' => 'required',
            'kota' => 'required',
            'provinsi' => 'required',
        ], [
            'user_id.required' => 'Wajib diisi!',
            'nama.required' => 'Wajib diisi!',
            'no_hp.required' => 'Wajib diisi!',
            'alamat.required' => 'Wajib diisi!',
            'kode_pos.required' => 'Wajib diisi!',
            'kecamatan.required' => 'Wajib diisi!',
            'kota.required' => 'Wajib diisi!',
            'provinsi.required' => 'Wajib diisi!',
        ]);

        try {

            Pelanggan::create([
                'user_id' => $validatedData['user_id'],
                'nama' => $validatedData['nama'],
                'no_hp' => $validatedData['no_hp'],
                'alamat' => $validatedData['alamat'],
                'kode_pos' => $validatedData['kode_pos'],
                'kecamatan' => $validatedData['kecamatan'],
                'kota' => $validatedData['kota'],
                'provinsi' => $validatedData['provinsi'],
                'negara' => 'Indonesia',
                'poin' => 0,
                'saldo' => 0,
            ]);

            DB::commit();

            toast('Penambahan data berhasil!', 'success');
            return redirect()->route('pelanggan.create');

        } catch (\Exception $e) {
            DB::rollback();

            toast('Penambahan data gagal!', 'warning');
            return redirect()->route('pelanggan.create');
        }
    }

    public function show($id)
    {
        $detailPelanggan = Pelanggan::join('users', 'users.id', '=', 'pelanggans.user_id')
            ->select('users.*', 'pelanggans.*')
            ->where('pelanggans.id', $id)
            ->get();

        return view('pengaturan.pelanggan.detailpelanggan', compact('detailPelanggan'));
    }

    public function edit($id)
    {
        //
    }

    // public function update(Request $request, $id)
    // {
    //     //
    // }

    public function destroy($id)
    {
        DB::beginTransaction();

        try {

            $cekPelangganTransaksi = Transaksi::where('pelanggan_id', $id)
                ->first();


            if ($cekPelangganTransaksi == null) {
                DB::statement('SET foreign_key_checks=0;');
                Pelanggan::where('id', $id)->delete();
                DB::statement('SET foreign_key_checks=1;');

                DB::commit();

                alert()->success('Hore!', 'Data Deleted Successfully');
                return redirect()->route('pelanggan.index');
            } else {
                alert()->error('Gagal!', 'Tidak bisa menghapus data karena data pelanggan terdapat di data penjualan');
                return redirect()->route('pelanggan.index');
            }

        } catch (\Exception $e) {

            DB::rollBack();

            alert()->error('Yahhh..', 'Menghapus data tidak berhasil!');
            return redirect()->route('pelanggan.index');
        }
    }


    public function katalog(Request $request)
    {
        $user = Auth::user();

        $pelanggan = Pelanggan::where('user_id', $user->id)->first();

        // dd($pelanggan);

        $selectedkategori = $request->input('kategori', []);
        $selectedstore = $request->input('store', []);
        $search = $request->query('search');

        $listProduct = Produk::select('id', 'foto_produk', 'nama', 'harga', (DB::raw("CONCAT(SUBSTRING_INDEX(deskripsi, ' ', 20),'...') AS deskripsi")))->get();

        if ($selectedkategori != null) {

            $listProduct = Produk::join('produk_tokos', 'produk_tokos.produk_id', '=', 'produks.id')
                ->join('subkategoris', 'subkategoris.id', '=', 'produks.subkategori_id')
                ->select('produks.id', 'produks.foto_produk', 'produks.nama', 'produks.harga', (DB::raw("CONCAT(SUBSTRING_INDEX(produks.deskripsi, ' ', 20),'...') AS deskripsi")))
                ->whereIn('subkategoris.kategori_id', $selectedkategori)
                ->where('produk_tokos.stok', '>', 0)
                ->get();
        }

        if ($selectedstore != null) {

            $listProduct = Produk::join('produk_tokos', 'produk_tokos.produk_id', '=', 'produks.id')
                ->select('produks.id', 'produks.foto_produk', 'produks.nama', 'produks.harga', (DB::raw("CONCAT(SUBSTRING_INDEX(produks.deskripsi, ' ', 20),'...') AS deskripsi")))
                ->whereIn('produk_tokos.toko_id', $selectedstore)
                ->where('produk_tokos.stok', '>', 0)
                ->get();
        }

        if ($selectedstore && $selectedkategori != null) {

            $listProduct = Produk::join('produk_tokos', 'produk_tokos.produk_id', '=', 'produks.id')
                ->join('subkategoris', 'subkategoris.id', '=', 'produks.subkategori_id')
                ->select('produks.id', 'produks.foto_produk', 'produks.nama', 'produks.harga', (DB::raw("CONCAT(SUBSTRING_INDEX(produks.deskripsi, ' ', 20),'...') AS deskripsi")))
                ->whereIn('subkategoris.kategori_id', $selectedkategori)
                ->whereIn('produk_tokos.toko_id', $selectedstore)
                ->where('produk_tokos.stok', '>', 0)
                ->get();
        }

        if ($search != null) {

            $listProduct = Produk::select('id', 'foto_produk', 'nama', 'harga', (DB::raw("CONCAT(SUBSTRING_INDEX(deskripsi, ' ', 20),'...') AS deskripsi")))
                ->where('nama', 'like', '%' . $search . '%')
                ->get();
        }


        $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->get();


        $subTotal = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->sum(DB::raw('produks.harga * keranjangs.kuantitas'));

        $vat = $subTotal * 20 / 100;
        $total = $subTotal + $vat;


        $count = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->count();

        $kategoris = Kategori::all();
        $stores = Toko::all();

        return view('checkout.index', compact('listProduct', 'listCart', 'subTotal', 'vat', 'total', 'count', 'kategoris', 'stores', 'selectedkategori', 'selectedstore'));
        // dd($listCart);
    }
    public function updateCart($id,$value){
        $user = Auth::user();
        $pelanggan = Pelanggan::where('user_id',$user->id)->first();

        $helper = Keranjang::where('pelanggan_id', '=', $pelanggan->id)->where('produk_id', '=', $id)->select('*')->first();
        // dd($helper);
        // $helper = DB::table('keranjangs')->select('*')->where('pelanggan_id', '=', $pelanggan->id)->where('produk_id', '=', $id)->first();
        if($helper->kuantitas != $value){
            $helper->kuantitas = $value;
        }
        $helper->update();
        return redirect()->route('cart');
    }
    public function addCart(Request $request, $id)
    {
        
        $user = Auth::user();
        // dd($user->id);
        $pelanggan = Pelanggan::where('user_id',$user->id)->first();
        // hardcode
        // $pelanggan = Pelanggan::where('user_id',5)->first();

        $selectedstore = $request->input('lokasi');
        // $store = DB::table('tokos')->select('id')->where('id', '=', $selectedstore)->first();

        if($request->input('kuantitas') > 0){
            $jumlah = $request->input('kuantitas');
        }else{
            $jumlah = 1;
        }
        $helper = DB::table('keranjangs')->select('*')->get()->where('pelanggan_id', '=', $pelanggan->id)->where('produk_id', '=', $id)->first();

        if($helper != null && $helper->toko_id == $selectedstore){
            DB::table('keranjangs')
                ->where('id', $helper->id)
                ->update([
                    'kuantitas' => ($helper->kuantitas + 1),
                    // Add more columns as needed
                ]);
        }else{
            $data = array('pt_produk_id'=>$id, 'pelanggan_id'=>$pelanggan->id, 'kuantitas'=>$jumlah, 'pt_toko_id'=>$selectedstore);
            DB::table('keranjangs')->insert($data);
        }

        // $pelanggan = 1;
        // dd($pelanggan);
        

        return redirect()->back();
    }

    public function cart(Request $request)
    {
        $user = Auth::user();

        $pelanggan = Pelanggan::where('user_id', $user->id)->first();

        $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
        ->join('tokos', 'tokos.id', '=', 'keranjangs.toko_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas', 'tokos.id as idstore', 'tokos.nama as namastore', 'produks.id as produk_id')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->get();

        // $listCart = DB::table('keranjangs as k')->select('k.id', 'p.fotoProduk', 'p.nama', 'p.harga', 'k.kuantitas', 'k.toko_id', 't.id as idstore', 't.nama as namastore')->join('produks as p', 'p.id', '=', 'k.produk_id')->join('tokos as t', 't.id', '=', 'k.toko_id')->where('k.pelanggan_id', '=', $pelanggan->id)->get();


        $subTotal = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->sum(DB::raw('produks.harga * keranjangs.kuantitas'));

        $vat = $subTotal * 20 / 100;
        $total = $subTotal + $vat;


        $store = Keranjang::join('produk_tokos', 'produk_tokos.produk_id', '=', 'keranjangs.produk_id')
            ->join('tokos', 'tokos.id', '=', 'produk_tokos.toko_id')
            ->select('tokos.*')
            ->get();

        $sidoarjo = Keranjang::where('toko_id', 1)->count();
        $malang = Keranjang::where('toko_id', 2)->count();
        $surabaya = Keranjang::where('toko_id', 3)->count();

        $choosen = $request->input('produk', []);
        $message = '';
        $count = 0;

        if ($choosen == null) {

            $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
                ->join('tokos', 'tokos.id', '=', 'keranjangs.toko_id')
                ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas', 'tokos.id as idstore', 'tokos.nama as namastore', 'produks.id as produk_id')
                ->where('keranjangs.pelanggan_id', $pelanggan->id)
                ->get();

            $subTotal = 0;
            $vat = 0;
            $total = 0;

            $store = Keranjang::join('produk_tokos', 'produk_tokos.produk_id', '=', 'keranjangs.produk_id')
                ->join('tokos', 'tokos.id', '=', 'produk_tokos.toko_id')
                ->select('tokos.*')
                ->get();

            $sidoarjo = Keranjang::where('toko_id', 1)->count();
            $malang = Keranjang::where('toko_id', 2)->count();
            $surabaya = Keranjang::where('toko_id', 3)->count();
        } else {

            $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
                ->join('tokos', 'tokos.id', '=', 'keranjangs.toko_id')
                ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas', 'tokos.id as idstore', 'tokos.nama as namastore', 'produks.id as produk_id')
                ->where('keranjangs.pelanggan_id', $pelanggan->id)
                ->get();

            $subTotal = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.produk_id')
                ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
                ->where('keranjangs.pelanggan_id', $pelanggan->id)
                ->sum(DB::raw('produks.harga * keranjangs.kuantitas'));

            $vat = $subTotal * 11 / 100;
            $total = $subTotal + $vat;

            $store = Keranjang::join('tokos', 'tokos.id', '=', 'keranjangs.toko_id')
                ->select('tokos.*')
                ->get();

            $sidoarjo = Keranjang::where('toko_id', 1)->count();
            $malang = Keranjang::where('toko_id', 2)->count();
            $surabaya = Keranjang::where('toko_id', 3)->count();

            // dd($subTotal);

            $toko = DB::table('keranjangs')->select('toko_id')->whereIn('id', $choosen)->groupBy('toko_id')->get();
            foreach ($toko as $t) {
                $count += 1;
                if ($count > 1) {
                    // return redirect()->back()->with('message', 'Products must be from the same store.');
                    // echo 'works';
                    $message = 'Products must be from the same store.';
                }
            }

        }

        // dd($listCart);

        return view('checkout.cart', compact('listCart', 'subTotal', 'vat', 'total', 'store', 'sidoarjo', 'malang', 'surabaya', 'choosen', 'message', 'count'));
    }

    public function cartHandler(Request $request)
    {
        $submitAction = $request->input('button');

        // Perform different actions based on the button clicked
        switch ($submitAction) {
            case 'checkout':
                // Handle action 2
                // $products = $request->input('produk', []);
                return $this->masukOrder($request);
                // dd($count);
                break;

            case 'delete':
                // Handle action 1
                $id = $request->input('id');
                return $this->deleteCart($id);
                break;

            default:
                // Handle the default case or return an error
                // $products = $request->input('produk', []);
                return $this->cart($request);
                break;
        }
    }

    public function deleteCart($id)
    {
        $listCart = DB::table('keranjangs')->where('id', '=', $id)->delete();
        // $listCart->destroy();
        // $cart->destroy($id);
        return redirect()->back();
    }
    public function deleteOutCart($id)
    {
        $listCart = DB::table('keranjangs')->where('id', '=', $id)->delete();
        // $listCart->destroy();
        return redirect()->back();
    }
    public function detail($id)
    {
        $user = Auth::user();

        $pelanggan = Pelanggan::where('user_id', $user->id)->first();

        $listCart = Keranjang::join('produks', 'produks.id', '=', 'keranjangs.pt_produk_id')
            ->select('produks.foto_produk', 'keranjangs.id', 'produks.nama', 'produks.harga', 'keranjangs.kuantitas')
            ->where('keranjangs.pelanggan_id', $pelanggan->id)
            ->get();


        $produk = Produk::join('produk_tokos', 'produk_tokos.produk_id', '=', 'produks.id')
            ->select('produks.*', 'produk_tokos.stok')
            ->where('produks.id', $id)
            ->first();


        $lokasi = Toko::join('produk_tokos', 'produk_tokos.toko_id', '=', 'tokos.id')
            ->select('tokos.*')
            ->where('produk_tokos.produk_id', $id)
            ->where('produk_tokos.stok', '>', 0)
            ->distinct('tokos.nama')
            ->get();


        $stok = ProdukToko::select('stok')
            ->where('produk_tokos.produk_id', $id)
            ->groupBy('produk_tokos.produk_id')
            ->sum('stok');

        $cekStock = ProdukToko::join('tokos', 'produk_tokos.toko_id', '=', 'tokos.id')
            ->select(DB::raw('SUM(produk_tokos.stok) as stok'), 'tokos.nama')
            ->where('produk_tokos.produk_id', $id)
            ->groupBy('produk_tokos.toko_id', 'tokos.nama')
            ->get();

        return view('checkout.detail', compact('produk', 'lokasi', 'stok', 'listCart', 'cekStock'));
        // dd($produk);
    }

    public function checkout($products)
    {
        $pelanggan = Pelanggan::where('user_id',Auth::user()->id)->first();
        // $products = $request->input('produk', []);
        $listCart = DB::table('keranjangs as k')->select('k.id')->where('k.pelanggan_id', '=', $pelanggan->id)->whereIn('k.id', $products)->groupBy('k.toko_id')->get();
        $count = $listCart->count();
        if ($count > 1)
        {
            return redirect()->back()->with('message', 'Products must be from the same store.');
            // dd($count);
        }
        else
        {
            return redirect()->back();
        }
        // dd($listCart);
    }

    public function updateQuantity($id)
    {
        $quantity = DB::table('keranjangs')->find($id);
        $quantity->kuantitas += 1;
        $quantity->save();

        return response()->json(['success' => true, 'message' => 'Count increased successfully']);
    }

    public function profile(){
        $user = Auth::user();
        $pelanggan = Pelanggan::where("user_id",$user->id)->first();
        $pelanggan->email = $user->email;
        $pelanggan->role_id = $user->role_id;
        $provinceList = Province::all();
        $cityList = City::all();
        return view('pelanggan.profile.profile',compact('pelanggan','provinceList','cityList'));
        // dd($pelanggan);
    }
    public function transactionHistory(){
        $user = Auth::user();
        $pelanggan = Pelanggan::where("user_id",$user->id)->first();
        $transactionList = Transaksi::where("pelanggan_id",$pelanggan->id)->get();
        return view('pelanggan.profile.transactionHIstory',compact('transactionList'));
        // dd($transactionList);
    }

    public function dompetHistory()
    {
        $user = Auth::user();
        $pelanggan = Pelanggan::where("user_id", $user->id)->first();
        $riwayatDompet = Dompet::where("pelanggan_id", $pelanggan->id)->get();
        return view('pelanggan.profile.dompetHistory', compact('riwayatDompet'));
        // dd($transactionList);
    }

    public function inserttopup(Request $request)
    {
        $user = Auth::user();
        $pelanggan = Pelanggan::where("user_id", $user->id)->first();

        if ($request->hasFile('bukti_transfer')) {
            $image = $request->file('bukti_transfer');
            $image->getClientOriginalName();
            $imageName = 'dompets/' . $image->getClientOriginalName();    
        }

        Dompet::create([
            'dana' => $request->input('dana'),
            'arus' => 'Masuk',
            'validasi_topup' => 0,
            'tanggal' => Carbon::now(),
            'bukti_transfer' => $imageName,
            'pelanggan_id' => $pelanggan->id,
        ]);

        $image->move(public_path('uploads/dompets'), $imageName);

        return redirect()->route('customer.dompet.history');
        // dd($transactionList);
    }

    public function validationTopUp(){
        $title = 'Delete Data!';
        $text = "Are you sure you want to delete?";
        confirmDelete($title, $text);

        // $dompets = Dompet::all();

        $dompets = Dompet::join('pelanggans', 'pelanggans.id', '=', 'riwayat_dompets.pelanggan_id')
            ->select('pelanggans.nama as nama_pelanggan', 'riwayat_dompets.*')
            ->get();

        return view('validationn.topup.index', compact('dompets'));
    }

    public function updateTopUpSetuju($id){
        $dompet = Dompet::find($id);

        $saldoDompet = Dompet::where('id', $id)
        ->value('dana');

        // dd($dompet);

        $dompet->update([
            'validasi_topup' => 1,
        ]);

        $saldoPelanggan = Pelanggan::where('id', $dompet->pelanggan_id)
            ->value('saldo');

        $saldoPelanggan += $saldoDompet;

        $pelanggan = Pelanggan::where('id', $dompet->pelanggan_id)->first();

        $pelanggan->update([
            'saldo' => $saldoPelanggan,
        ]);

        return redirect()->route('validation.topup');
    }

    public function updateTopUpTolak($id)
    {
        $dompet = Dompet::find($id);

        $dompet->update([
            'validasi_topup' => 2,
        ]);

        return redirect()->route('validation.topup');
    }

    public function update(Request $request)
    {
        $user = Auth::user();
        $pelanggan = Pelanggan::where('user_id',$user->id)->first();
        // dd($request);
        if($pelanggan->nama != $request->input('name')){
            $pelanggan->nama = $request->input('name');
            $user->nama = $pelanggan->nama;
        }
        if($user->email != $request->input('email')){
            $user->email = $request->input('email');
        }
        if($pelanggan->no_hp != $request->input('phone')){
            $pelanggan->no_hp = $request->input('phone');
        }
        if($pelanggan->alamat != $request->input('address')){
            $pelanggan->alamat = $request->input('address');
        }
        if($pelanggan->kode_pos != $request->input('postal')){
            $pelanggan->kode_pos = $request->input('postal');
        }
        if($pelanggan->provinsi != $request->input("province")){
            $pelanggan->provinsi = $request->input('province');
        }
        if($pelanggan->kota != $request->input('kota')){
            $pelanggan->kota = $request->input('kota');
        }
        $pelanggan->update();
        return redirect()->route('customer.profile');
    }


    public function masukOrder(Request $request)
    {
        $user = Auth::user();
        $pelanggan = Pelanggan::where("user_id",$user->id)->first();
        $dompet = $pelanggan->saldo;

        $selectedItems = json_decode($request->input('produk_array'));
        $listKeranjang = [];
        $totalHarga = 0;
        
        setlocale(LC_TIME, 'id_ID');
        $today = Carbon::now('Asia/Jakarta');
        
        //cari id kota pelanggan
        $kota_tujuan = $user->pelanggans->kota;
        $kota_tujuan_id = City::Where('name', $kota_tujuan)->value('id');

        $ongkirList = [];
        foreach ($selectedItems as $item) {
            $keranjang = Keranjang::where('id', $item)
            ->with('produks')
            ->with('tokos')
            ->first();

            $kotaToko = Keranjang::join('tokos', 'keranjangs.toko_id', '=', 'tokos.id')
            ->value('tokos.kota');

            // dd($kotaToko);
            //cari id kota toko pengirim
            $kota_toko_id = City::Where('name', $kotaToko)->value('id');

            $responseCost = Http::withHeaders([
                'key' => '9335a6b808be9ab68fb8bfa6458079c1'
            ])->post('https://api.rajaongkir.com/starter/cost', [
                'origin' => $kota_toko_id,
                'destination' => $kota_tujuan_id,
                'weight' => 1000,
                'courier'=>'jne',
            ]);

            $ongkir = $responseCost['rajaongkir']['results'];
            $ongkirList[] = $ongkir;

            $listKeranjang[] = $keranjang;
            $totalHarga += $keranjang->produks->harga*$keranjang->kuantitas;
        }

        $totals = [];
        foreach ($ongkirList as $item) {
            $totalValues = [];
            $estimasiKirim = [];

            foreach ($item[0]['costs'] as $cost) {
                $service = $cost['service'];
                $value = $cost['cost'][0]['value'];
                
                $nilai = $cost['cost'][0]['etd'];
                $arrayNilai = explode('-', $nilai);
                $nilaiTerakhir = end($arrayNilai);

                if (isset($totalValues[$service])) {
                    $totalValues[$service] += $value;
                    foreach ($estimasiKirim as $key => $valueWaktu) {
                        if ($key == $service){
                            continue;
                        } else {
                            $tanggalSampai = $today->addDays($nilaiTerakhir); 
                            $tanggalSampai->setLocale('id');
                            $formattedDate = $tanggalSampai->formatLocalized('%d %B %Y');
                            $estimasiKirim[$service] = $formattedDate;
                        }
                    }
                } else {
                    $totalValues[$service] = $value;
                    $tanggalSampai = $today->addDays($nilaiTerakhir); 
                    $tanggalSampai->setLocale('id');
                    $formattedDate = $tanggalSampai->formatLocalized('%d %B %Y');
                    $estimasiKirim[$service] = $formattedDate;
                }
            }
            $totals[] = $totalValues;
        }

        $mergedTotals = [];
        foreach ($totals as $item) {
            foreach ($item as $service => $value) {
                if (!isset($mergedTotals[$service])) {
                    $mergedTotals[$service] = 0;
                }
                $mergedTotals[$service] += $value;
            }
        }
        
        return view('checkout.detailorder', compact('listKeranjang', 'user', 'dompet', 'totalHarga', 'estimasiKirim' ,'mergedTotals'));
    }

    public function buatOrder(Request $request)
    {
        DB::beginTransaction();
        try {
            $keranjang = $request->input('keranjang');
            $user = Auth::user();
            $pelanggan = $user->pelanggans;
            $tanggalWaktu = now();

            $totalHarga = $request->input('total_harga');
            $service = $request->input('service');

            // $dompet = $user->dompet;
            // $riwayatDompet = new RiwayatDompet();
            // $riwayatDompet->dana = $totalHarga;
            // $riwayatDompet->arus = "Keluar";
            // $riwayatDompet->validasi_topup = 1;
            // $riwayatDompet->tanggal = Carbon::now('Asia/Jakarta');
            // $riwayatDompet->dompet_id = $dompet->id;
            // $riwayatDompet->save();

            $pelanggan->saldo -= $totalHarga;
            $pelanggan->poin += $totalHarga*0.01;
            $pelanggan->save();
            //cari id kota pelanggan
            $kota_tujuan = $user->pelanggans->kota;
            $kota_tujuan_id = DB::table('cities')->Where('name', $kota_tujuan)->select('city_id')->get();

            $toko_id = Keranjang::where('id', $keranjang[0])->select('toko_id')->first();
            $transaksi = new Transaksi();
            $transaksi->kode_nota = "{$user->id}-" . $tanggalWaktu->format('YmdHis');
            $transaksi->pelanggan_id = $user->pelanggans->id;
            $transaksi->toko_id = $toko_id->toko_id;
            $transaksi->status = "Diproses";
            $transaksi->grand_total = $totalHarga;
            $transaksi->poin = $totalHarga*0.01;
            $transaksi->pengiriman = $request->input('input_metode_pengiriman');
            $transaksi->tipe_jasa_kirim = $service;
            $transaksi->save();

            $subtotal = 0;
            $biayaOngkir = 0;
            foreach ($keranjang as $keranjang_id) {
                $produk_keranjang = Keranjang::where('id', $keranjang_id)->with('toko')->first();

                $produk_toko_id = DB::table('produk_tokos')->select('id')
                                    ->where('toko_id', '=', $produk_keranjang->toko_id)
                                    ->where('produk_id', '=', $produk_keranjang->produk_id)->get();
                $produk = DB::table('produks')->where('id', '=', $produk_keranjang->produk_id)->get();

                $detailTransaksi = new DetailTransaksi();
                $detailTransaksi->transaksi_id = $transaksi->id;
                $detailTransaksi->produk_toko_id = $produk_toko_id[0]->id;
                $detailTransaksi->kuantitas = $produk_keranjang->kuantitas;
                $detailTransaksi->total = $produk[0]->harga*$produk_keranjang->kuantitas;
                $detailTransaksi->save();

                $subtotal += $produk[0]->harga*$produk_keranjang->kuantitas;
                
                //cari id kota toko pengirim
                $kota_toko_id = DB::table('cities')->Where('name', $produk_keranjang->toko->kota)->select('city_id')->get();
                //perhitungan ongkir
                $responseCost = Http::withHeaders([
                    'key' => '9335a6b808be9ab68fb8bfa6458079c1'
                ])->post('https://api.rajaongkir.com/starter/cost', [
                    'origin'=> $kota_toko_id[0]->city_id,
                    'destination' => $kota_tujuan_id[0]->city_id,
                    'weight'=> $produk[0]->berat*100,
                    'courier'=>'jne',
                ]);
                $ongkir = $responseCost['rajaongkir']['results'];

                foreach ($ongkir[0]['costs'] as $ong) {
                    if ($service == $ong['service']){
                        $biayaOngkir += $ong['cost'][0]['value'];
                    }
                }

                // $riwayatDompetVendor = new RiwayatDompet();
                // $riwayatDompetVendor->dana = $subtotal;
                // $riwayatDompetVendor->arus = "Masuk";
                // $riwayatDompetVendor->validasi_topup = 1;
                // $riwayatDompetVendor->tanggal = Carbon::now('Asia/Jakarta');
                // $riwayatDompetVendor->dompet_id = $vendorUser->dompet->id;
                // $riwayatDompetVendor->save();

                // $riwayatDompetVendorOngkir = new RiwayatDompet();
                // $riwayatDompetVendorOngkir->dana = $biayaOngkir;
                // $riwayatDompetVendorOngkir->arus = "Masuk";
                // $riwayatDompetVendorOngkir->validasi_topup = 1;
                // $riwayatDompetVendorOngkir->tanggal = Carbon::now('Asia/Jakarta');
                // $riwayatDompetVendorOngkir->dompet_id = $vendorUser->dompet->id;
                // $riwayatDompetVendorOngkir->save();

                // $vendorUser->dompet->saldo += $subtotal + $biayaOngkir;
                // $vendorUser->dompet->save();

                Keranjang::where('id', $keranjang_id)->delete();
            }

            $biayaPajak = $subtotal*0.11;
            // $table->text('keterangan')->nullable();      

            if ($transaksi->pengiriman == 'Ambil Toko') {
                $transaksi->biaya_pengiriman = 0;
            } else {
                $transaksi->biaya_pengiriman = $biayaOngkir;
            }
            $transaksi->subtotal = $subtotal;
            $transaksi->biaya_pajak = $biayaPajak;
            // $transaksi->grand_total = ;
            $transaksi->save();

            DB::commit();
            return redirect()->route('listProduct')->with('berhasil', 'Pembelian berhasil dilakukan.');
        } catch (\Exception $e) {
            DB::rollBack();
            $pesanGagal = 'Pembelian gagal. Terjadi kesalahan.';
            $pesanGagal .= ' Silakan hubungi teknisi kami untuk bantuan lebih lanjut.';

            return redirect()->route('listProduct')->with('gagal', $pesanGagal);
        }
    }
}
