@extends('ekka.shop')

@section('content')
<section class="ec-page-content ec-vendor-uploads ec-user-account section-space-p">
    <div class="container">
        <div class="row">
            <!-- Sidebar Area Start -->
            <div class="ec-shop-leftside ec-vendor-sidebar col-lg-3 col-md-12">
                <div class="ec-sidebar-wrap">
                    <!-- Sidebar Category Block -->
                    <div class="ec-sidebar-block">
                        <div class="ec-vendor-block">
                            <div class="ec-vendor-block-items">
                                <ul>
                                    <li><a href="user-profile.html">User Profile</a></li>
                                    <li><a href="user-history.html">History</a></li>
                                    <li><a href="wishlist.html">Wishlist</a></li>
                                    <li><a href="cart.html">Cart</a></li>
                                    <li><a href="checkout.html">Checkout</a></li>
                                    <li><a href="track-order.html">Track Order</a></li>
                                    <li><a href="user-invoice.html">Invoice</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ec-shop-rightside col-lg-9 col-md-12">
                <div class="ec-vendor-dashboard-card">
                    <div class="ec-vendor-card-header">
                        <h5>Product History</h5>
                        <div class="ec-header-btn">
                            <a class="btn btn-lg btn-primary" href="#">Shop Now</a>
                        </div>
                    </div>
                    <div class="ec-vendor-card-body">
                        <div class="ec-vendor-card-table">
                            <table class="table ec-table">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row"><span>225</span></th>
                                        <td><img class="prod-img" src="assets/images/product-image/1.jpg"
                                                alt="product image"></td>
                                        <td><span>Stylish baby shoes</span></td>
                                        <td><span>16 Jul 2021</span></td>
                                        <td><span>$65</span></td>
                                        <td><span>Active</span></td>
                                        <td><span class="tbl-btn"><a class="btn btn-lg btn-primary"
                                                    href="#">View</a></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><span>548</span></th>
                                        <td><img class="prod-img" src="assets/images/product-image/2.jpg"
                                                alt="product image"></td>
                                        <td><span>Sweat Pullover Hoodie</span></td>
                                        <td><span>13 Aug 2016</span></td>
                                        <td><span>$68</span></td>
                                        <td><span>On Hold</span></td>
                                        <td><span class="tbl-btn"><a class="btn btn-lg btn-primary"
                                                    href="#">View</a></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><span>684</span></th>
                                        <td><img class="prod-img" src="assets/images/product-image/3.jpg"
                                                alt="product image"></td>
                                        <td><span>T-shirt for girl</span></td>
                                        <td><span>20 Jul 2015</span></td>
                                        <td><span>$360</span></td>
                                        <td><span>On Hold</span></td>
                                        <td><span class="tbl-btn"><a class="btn btn-lg btn-primary"
                                                    href="#">View</a></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><span>987</span></th>
                                        <td><img class="prod-img" src="assets/images/product-image/4.jpg"
                                                alt="product image"></td>
                                        <td><span>Wool hat for men</span></td>
                                        <td><span>05 Feb 2014</span></td>
                                        <td><span>$584</span></td>
                                        <td><span>On Hold</span></td>
                                        <td><span class="tbl-btn"><a class="btn btn-lg btn-primary"
                                                    href="#">View</a></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><span>225</span></th>
                                        <td><img class="prod-img" src="assets/images/product-image/5.jpg"
                                                alt="product image"></td>
                                        <td><span>Women leather purse</span></td>
                                        <td><span>23 Jul 2013</span></td>
                                        <td><span>$65</span></td>
                                        <td><span>On Hold</span></td>
                                        <td><span class="tbl-btn"><a class="btn btn-lg btn-primary"
                                                    href="#">View</a></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><span>548</span></th>
                                        <td><img class="prod-img" src="assets/images/product-image/6.jpg"
                                                alt="product image"></td>
                                        <td><span>Doctor kit toy</span></td>
                                        <td><span>28 Mar 2011</span></td>
                                        <td><span>$68</span></td>
                                        <td><span>Disabled</span></td>
                                        <td><span class="tbl-btn"><a class="btn btn-lg btn-primary"
                                                    href="#">View</a></span></td>
                                    </tr>
                                    <tr>
                                        <th scope="row"><span>684</span></th>
                                        <td><img class="prod-img" src="assets/images/product-image/7.jpg"
                                                alt="product image"></td>
                                        <td><span>Teddy bear for baby</span></td>
                                        <td><span>16 Apr 2010</span></td>
                                        <td><span>$360</span></td>
                                        <td><span>On Hold</span></td>
                                        <td><span class="tbl-btn"><a class="btn btn-lg btn-primary"
                                                    href="#">View</a></span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection